package game;

import java.util.List;

import game.io.WerewolfIOHandler;
import roles.Player;

public class DefaultGameBuilder extends GameBuilder {
	
	/* (non-Javadoc)
	 * @see game.GameFactory#createGame(java.util.List, game.io.WerewolfInputStream, game.io.WerewolfOutputStream)
	 */
	@Override
	public Game buildGame(List<String> playerNames, WerewolfIOHandler ioHandler) throws InvalidPlayerCountException {
		//TODO Aufgabe 1e
		throw new UnsupportedOperationException("Not implemented yet!");
	}
	
	/* (non-Javadoc)
	 * @see game.GameFactory#assignRoles(java.util.List)
	 */
	@Override
	protected List<Player> assignRoles(List<String> playerNames) throws InvalidPlayerCountException {
		//TODO Aufgabe 1e
		throw new UnsupportedOperationException("Not implemented yet!");
	}

}
