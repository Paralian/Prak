package phases;

import java.util.ArrayList;
import java.util.List;

import game.Poll;
import phases.result.*;

import roles.*;

public class WerewolfNight extends Phase {
    
    public WerewolfNight(List<Player> players) {
        super(players);
    }
    
    /* (non-Javadoc)
     * @see phases.Phase#preparePlayers(java.util.List)
     */
    @Override
    protected void preparePlayers(List<Player> players) {
        for (Player numberOfPlayer : players) {
            if (numberOfPlayer.getStatus() != Player.PlayerStatus.DEAD) {
                if (players instanceof Werewolf) {
                    numberOfPlayer.setStatus(Player.PlayerStatus.AWAKE);
                } else {
                    numberOfPlayer.setStatus(Player.PlayerStatus.ASLEEP);
                }
            }
        }
    }
    
    /* (non-Javadoc)
     * @see phases.Phase#concludePhase()
     */
    @Override
    public PhaseResult concludePhase() {
        if (poll.isConclusive()) {
            Player target = poll.getVotedPlayer();
            target.setStatus(Player.PlayerStatus.DEAD);
            return new PlayerKilledResult(target);
        }
        else {
            return new VoteFailedResult();
        }
    }
    
    /* (non-Javadoc)
     * @see phases.Phase#preparePoll(java.util.List)
     */
    @Override
    protected Poll preparePoll(List<Player> players) {
        List<Player> werwolfs = new ArrayList<>(); // #SänkJüForTräwelingWisDeutscheBahn
        List<Player> alives = new ArrayList<>();
        for (Player numberOfPlayer : players) {
            if (numberOfPlayer.getStatus() != Player.PlayerStatus.DEAD) {
                alives.add(numberOfPlayer);
                if (numberOfPlayer instanceof Werewolf) {
                    werwolfs.add(numberOfPlayer);
                }
            }
        }
        return new Poll(werwolfs, alives);
    }
    
    /* (non-Javadoc)
     * @see phases.Phase#voteIsValid(roles.Player, roles.Player)
     */
    @Override
    protected boolean voteIsValid(Player voter, Player target) {
        //TODO Aufgabe 1b
        throw new UnsupportedOperationException("Not implemented yet!");
    }
}
