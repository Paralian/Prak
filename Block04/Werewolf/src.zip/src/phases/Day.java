package phases;

import java.util.ArrayList;
import java.util.List;

import game.Poll;
import phases.result.*;
import roles.Player;
import roles.Player.PlayerStatus;

public class Day extends Phase {
    
    public Day(List<Player> players) {
        super(players);
    }
    
    /* (non-Javadoc)
     * @see phases.Phase#preparePlayers(java.util.List)
     */
    @Override
    protected void preparePlayers(List<Player> players) {
        for (Player player : players) {
            if (player.isAlive()) {
                player.setStatus(PlayerStatus.AWAKE);
            }
        }
    }
    
    /* (non-Javadoc)
     * @see phases.Phase#preparePoll(java.util.List)
     */
    @Override
    protected Poll preparePoll(List<Player> players) {
        List<Player> playerss = new ArrayList<>();
        List<Player> alives = new ArrayList<>();
        for (Player numberOfPlayer : players) {
            if (numberOfPlayer.getStatus() != Player.PlayerStatus.DEAD) {
                alives.add(numberOfPlayer);
                if (numberOfPlayer instanceof Player) {
                    playerss.add(numberOfPlayer);
                }
            }
        }
        return new Poll(playerss, alives);
    }
    
    /* (non-Javadoc)
     * @see phases.Phase#concludePhase()
     */
    @Override
    public PhaseResult concludePhase() {
        if (poll.isConclusive()) {
            Player target = poll.getVotedPlayer();
            target.setStatus(Player.PlayerStatus.DEAD);
            return new PlayerKilledResult(target);
        } else {
            return new VoteFailedResult();
        }
    }
    
    /* (non-Javadoc)
     * @see phases.Phase#voteIsValid(roles.Player, roles.Player)
     */
    @Override
    protected boolean voteIsValid(Player voter, Player target) {
        return true;
    }
}