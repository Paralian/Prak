package roles;

public class Seer extends Townie {
    
    
    public Seer(String name) {
        super(name);
    }
    
    /**
     * Returns the target player's alignment.
     *
     * @param player the target player.
     * @return PlayerAlignment.WEREWOLF if the player is a werewolf,<br>PlayerAlignment.OTHER otherwise.
     */
    public PlayerAlignment revealPlayerAlignment(Player player) {
        PlayerAlignment playerAlignment = PlayerAlignment.UNKNOWN;
        if (player.isAlive()) {
            if (player instanceof Werewolf) {
                playerAlignment = PlayerAlignment.WEREWOLF;
            } else {
                playerAlignment = PlayerAlignment.OTHER;
            }
        }
        return playerAlignment;
    }
    
    public enum PlayerAlignment {
        WEREWOLF,
        OTHER,
        UNKNOWN
    }
    
}
