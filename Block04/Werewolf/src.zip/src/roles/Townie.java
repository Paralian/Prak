package roles;

import java.util.List;

public class Townie extends Player {
    
    public Townie(String name) {
        super(name);
    }
    
    /* (non-Javadoc)
     * @see roles.Player#hasWon(java.util.List)
     */
    @Override
    public boolean hasWon(List<Player> players) {
        int W = 0;
        for (Player numberOfPlayer : players) {
            if (numberOfPlayer.getStatus() != PlayerStatus.DEAD) {
                if (numberOfPlayer instanceof Werewolf) {
                    W++;
                }
            }
        }
        
        return W == 0;
    }
    
}


