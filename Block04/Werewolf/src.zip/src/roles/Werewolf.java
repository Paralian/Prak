package roles;

import java.util.List;

public class Werewolf extends Player {
    
    
    public Werewolf(String name) {
        super(name);
    }
    
    /* (non-Javadoc)
     * @see roles.Player#hasWon(java.util.List)
     */
    @Override
    public boolean hasWon(List<Player> players) {
        int W = 0;
        int T = 0;
        for (Player numberOfPlayer : players) {
            if (numberOfPlayer.getStatus() != PlayerStatus.DEAD) {
                if (numberOfPlayer instanceof Werewolf) {
                    W++;
                } else {
                    T++;
                }
            }
        }
        return W >= T;
        
    }
    
}
